/*
 Test file for use with iFrameProxyClient.js
 iFrameProxyClient.js tries to load this file in a script tag.
 If the file fails to load with an error, we short circuit
 the wait to load "iFrameProxyRelease.html" and assume
 it will fail. Removing this file will cause iFrameProxyClient
 to think the iframe will fail to load.
 */